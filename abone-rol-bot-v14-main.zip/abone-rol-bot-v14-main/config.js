module.exports = {
    "token": "", // Botunuzun tokeni
    "rol": "", // Abone rolü idsi
    "kanal": "", // Kullanıcıların ekran görüntüsünü atacağı kanal
    "log": "", // Abone rolü logu (Başarılı veya başarısız)
    "kanalad": ""// YouTube kanalınızın adı
}